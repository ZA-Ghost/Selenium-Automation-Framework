package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.Map;

/**
 * BaseTest is the parent class for all test classes.
 *
 * It centralises the browser setup and teardown logic so that
 * no individual test class needs to handle driver initialisation.
 * All test classes extend this to inherit a ready WebDriver instance.
 */
public class BaseTest {

    protected WebDriver driver;

    /**
     * Runs once before any tests in the class execute.
     * Sets up WebDriverManager, configures ChromeOptions,
     * launches the browser, and navigates to the SauceDemo login page.
     */
    @BeforeClass
    public void setUp() {
        ChromeOptions options = new ChromeOptions();

        // ── Suppress automation banners and notifications ──────────────────────
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-save-password-bubble");
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});

        // ── Suppress "Change your password" / breach detection dialog ─────────
        options.addArguments("--disable-features=PasswordLeakDetection,SafeBrowsingEnhancedProtection,TrustSafetySentimentSurvey");

        // ── Disable Chrome password manager via prefs ──────────────────────────
        options.setExperimentalOption("prefs", Map.of(
                "credentials_enable_service",                              false,
                "profile.password_manager_enabled",                        false,
                "profile.password_manager_leak_detection",                 false,
                "profile.default_content_setting_values.notifications",    2
        ));

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com/");
    }


    /**
     * Runs once after all tests in the class have finished.
     * Closes the browser and ends the WebDriver session to free resources.
     */
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}