package pages;

import base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * LoginPage represents the SauceDemo login screen.
 *
 * It encapsulates all elements and interactions specific to logging in,
 * so the test class never needs to know about element locators or
 * field names on this page.
 */
public class LoginPage extends BasePage {

    // @FindBy is a PageFactory annotation that locates the element by its HTML id attribute
    @FindBy(id = "user-name")
    private WebElement usernameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    /**
     * Passes the WebDriver instance up to BasePage for shared initialisation.
     *
     * @param driver The active WebDriver session
     */
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Types the provided credentials into the login form and submits it.
     *
     * @param username The username to enter
     * @param password The password to enter
     */
    public void login(String username, String password) {
        usernameField.sendKeys(username);   // Type the username into the username input field
        passwordField.sendKeys(password);   // Type the password into the password input field
        loginButton.click();                // Click the login button to submit the form
    }
}