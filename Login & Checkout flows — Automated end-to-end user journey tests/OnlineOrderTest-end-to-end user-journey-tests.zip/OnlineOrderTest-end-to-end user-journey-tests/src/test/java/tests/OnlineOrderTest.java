package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

/**
 * OnlineOrderTest validates the complete end-to-end purchase flow on SauceDemo.
 *
 * Covers the full user journey: login → add to cart → cart → checkout form
 * → order overview → order confirmation.
 *
 * Thread.sleep() pauses are added between steps so each stage is clearly
 * visible during test execution — useful for demos, reviews, and debugging.
 */
public class OnlineOrderTest extends BaseTest {

    /**
     * Test 1: Verifies that a user can log in with valid credentials.
     * Pauses after login so the Products page is clearly visible before the next step.
     */
    @Test(priority = 1)
    public void testLogin() throws InterruptedException {
        Thread.sleep(1500); // Wait before starting — lets the login page fully render

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("standard_user", "secret_sauce");

        Thread.sleep(2000); // Pause so the Products page is visible after login

        InventoryPage inventoryPage = new InventoryPage(driver);
        Assert.assertEquals(inventoryPage.getPageTitle(), "Products",
                "Login failed — Products page title not found.");
    }

    /**
     * Test 2: Verifies that a product can be added to the shopping cart.
     * Pauses after clicking so the cart badge animation is visible.
     */
    @Test(priority = 2)
    public void testAddToCart() throws InterruptedException {
        Thread.sleep(1500); // Pause before interacting with the product listing

        InventoryPage inventoryPage = new InventoryPage(driver);
        inventoryPage.addBackpackToCart();

        Thread.sleep(1500); // Pause so the cart badge update is clearly visible

        Assert.assertEquals(inventoryPage.getCartBadgeCount(), "1",
                "Cart badge did not update — item may not have been added.");
    }

    /**
     * Test 3: Verifies that clicking the cart icon opens the Cart page.
     * Pauses after navigation so the cart contents are clearly visible.
     */
    @Test(priority = 3)
    public void testGoToCartPage() throws InterruptedException {
        Thread.sleep(1500); // Pause before clicking the cart icon

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();

        Thread.sleep(2000); // Pause so the cart page and its items are clearly visible

        Assert.assertTrue(cartPage.isCartTitleDisplayed(),
                "Cart page did not load — 'Your Cart' title not found.");
    }

    /**
     * Test 4: Verifies that clicking Checkout opens the checkout information form.
     * Pauses after clicking so the form is fully visible before the next test.
     */
    @Test(priority = 4)
    public void testCheckoutStart() throws InterruptedException {
        Thread.sleep(1500); // Pause before clicking Checkout

        CartPage cartPage = new CartPage(driver);
        cartPage.proceedToCheckout();

        Thread.sleep(2000); // Pause so the checkout information form is clearly visible

        CheckoutInfoPage checkoutInfoPage = new CheckoutInfoPage(driver);
        Assert.assertTrue(checkoutInfoPage.isTitleDisplayed(),
                "Checkout information page did not load.");
    }

    /**
     * Test 5: Verifies that customer information can be submitted on the checkout form.
     * Pauses after each field entry so the typing is visible, then pauses on the overview.
     */
    @Test(priority = 5)
    public void testCheckoutInformation() throws InterruptedException {
        Thread.sleep(1000); // Pause before starting to fill in the form

        CheckoutInfoPage checkoutInfoPage = new CheckoutInfoPage(driver);
        checkoutInfoPage.fillInformation("Khwezi", "Test", "1234");

        Thread.sleep(2000); // Pause so the order overview page is clearly visible

        CheckoutOverviewPage overviewPage = new CheckoutOverviewPage(driver);
        Assert.assertTrue(overviewPage.isTitleDisplayed(),
                "Checkout overview page did not load after submitting information.");
    }

    /**
     * Test 6: Verifies that the order can be successfully completed.
     * Pauses after clicking Finish so the confirmation screen is clearly visible.
     */
    @Test(priority = 6)
    public void testFinishCheckout() throws InterruptedException {
        Thread.sleep(1500); // Pause before clicking Finish — lets the overview page settle

        CheckoutOverviewPage overviewPage = new CheckoutOverviewPage(driver);
        overviewPage.finishOrder();

        Thread.sleep(3000); // Longer pause on the confirmation screen — this is the end result

        ConfirmationPage confirmationPage = new ConfirmationPage(driver);
        Assert.assertEquals(confirmationPage.getConfirmationText(), "Thank you for your order!",
                "Order confirmation message not displayed — checkout may have failed.");
    }
}