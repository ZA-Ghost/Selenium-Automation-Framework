package pages;

import base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * CartPage represents the shopping cart page (Your Cart).
 *
 * It provides methods to verify the cart page has loaded
 * and to proceed to the checkout flow.
 */
public class CartPage extends BasePage {

    // The cart icon link in the top navigation — clicking it opens the cart
    @FindBy(xpath = "//div[@id='shopping_cart_container']/a")
    private WebElement cartIcon;

    // The "Your Cart" heading displayed at the top of the cart page
    @FindBy(xpath = "//span[contains(text(),'Your Cart')]")
    private WebElement cartTitle;

    // The "Checkout" button that advances the user to the checkout information form
    @FindBy(id = "checkout")
    private WebElement checkoutButton;

    /**
     * @param driver The active WebDriver session
     */
    public CartPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Clicks the shopping cart icon in the navigation bar to open the cart page.
     */
    public void openCart() {
        cartIcon.click();
    }

    /**
     * Returns whether the "Your Cart" title is currently displayed.
     * Used to confirm that the cart page loaded after clicking the cart icon.
     *
     * @return true if the title is visible, false otherwise
     */
    public boolean isCartTitleDisplayed() {
        return cartTitle.isDisplayed();
    }

    /**
     * Clicks the Checkout button on the cart page to proceed to the checkout form.
     */
    public void proceedToCheckout() {
        checkoutButton.click();
    }
}