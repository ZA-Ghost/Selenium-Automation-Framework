package pages;

import base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * InventoryPage represents the Products listing page shown after login.
 *
 * It provides methods to interact with the product catalogue,
 * such as adding items to the cart, and to read the cart badge count.
 */
public class InventoryPage extends BasePage {

    // The page title element used to verify that the inventory page has loaded
    @FindBy(className = "title")
    private WebElement pageTitle;

    // The "Add to cart" button for the Sauce Labs Backpack product
    @FindBy(id = "add-to-cart-sauce-labs-backpack")
    private WebElement addBackpackButton;

    // The cart badge that displays the number of items currently in the cart
    @FindBy(className = "shopping_cart_badge")
    private WebElement cartBadge;

    /**
     * @param driver The active WebDriver session
     */
    public InventoryPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Returns the text of the page title element (e.g. "Products").
     * Used by tests to confirm the inventory page loaded successfully after login.
     *
     * @return The visible title text
     */
    public String getPageTitle() {
        return pageTitle.getText();
    }

    /**
     * Clicks the "Add to Cart" button for the Sauce Labs Backpack.
     */
    public void addBackpackToCart() {
        addBackpackButton.click();
    }

    /**
     * Returns the number shown on the cart badge.
     * Used to verify that an item was successfully added to the cart.
     *
     * @return The cart item count as a String (e.g. "1")
     */
    public String getCartBadgeCount() {
        return cartBadge.getText();
    }
}