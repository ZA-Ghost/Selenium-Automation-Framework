package pages;

import base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * ConfirmationPage represents the order confirmation page shown after checkout.
 *
 * It provides access to the confirmation header text, which is used
 * to assert that the order was placed successfully.
 */
public class ConfirmationPage extends BasePage {

    // The "Thank you for your order!" heading displayed after a successful purchase
    @FindBy(className = "complete-header")
    private WebElement confirmationHeader;

    /**
     * @param driver The active WebDriver session
     */
    public ConfirmationPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Returns the text of the order confirmation header.
     * Used by the test to assert the expected success message is displayed.
     *
     * @return The confirmation message text (e.g. "Thank you for your order!")
     */
    public String getConfirmationText() {
        return confirmationHeader.getText();
    }
}