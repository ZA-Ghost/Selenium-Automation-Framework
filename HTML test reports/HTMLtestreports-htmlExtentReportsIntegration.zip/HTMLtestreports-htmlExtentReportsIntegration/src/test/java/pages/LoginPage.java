package pages;

import base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * LoginPage represents the SauceDemo login screen.
 *
 * Encapsulates all elements and interactions on the login page,
 * including both the login form and the error message displayed
 * when credentials are invalid or the account is locked out.
 */
public class LoginPage extends BasePage {

    @FindBy(id = "user-name")
    private WebElement usernameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "login-button")
    private WebElement loginButton;

    // The error message container shown when login fails
    @FindBy(css = "[data-test='error']")
    private WebElement errorMessage;

    /**
     * @param driver The active WebDriver session
     */
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Types the provided credentials into the login form and submits it.
     *
     * @param username The username to enter
     * @param password The password to enter
     */
    public void login(String username, String password) {
        usernameField.clear();            // Clear any pre-filled value before typing
        usernameField.sendKeys(username);
        passwordField.clear();            // Clear any pre-filled value before typing
        passwordField.sendKeys(password);
        loginButton.click();
    }

    /**
     * Returns the error message text shown when login fails.
     * Used to assert the correct error is displayed for invalid or locked accounts.
     *
     * @return The visible error message string
     */
    public String getErrorMessage() {
        return errorMessage.getText();
    }
}