package pages;

import base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * CheckoutInfoPage represents the "Checkout: Your Information" form page.
 *
 * It encapsulates the shipping details form where the user enters
 * their first name, last name, and postal code before proceeding
 * to the order overview.
 */
public class CheckoutInfoPage extends BasePage {

    // The page heading that confirms we are on the checkout information step
    @FindBy(xpath = "//span[contains(text(),'Checkout: Your Information')]")
    private WebElement checkoutTitle;

    // The first name input field on the checkout form
    @FindBy(id = "first-name")
    private WebElement firstNameField;

    // The last name input field on the checkout form
    @FindBy(id = "last-name")
    private WebElement lastNameField;

    // The postal code input field on the checkout form
    @FindBy(id = "postal-code")
    private WebElement postalCodeField;

    // The Continue button that submits the form and moves to the order overview
    @FindBy(id = "continue")
    private WebElement continueButton;

    /**
     * @param driver The active WebDriver session
     */
    public CheckoutInfoPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Returns whether the checkout information page title is displayed.
     * Used to confirm navigation to this step after clicking Checkout on the cart page.
     *
     * @return true if the title is visible, false otherwise
     */
    public boolean isTitleDisplayed() {
        return checkoutTitle.isDisplayed();
    }

    /**
     * Fills in the shipping information fields and submits the form.
     *
     * @param firstName  The customer's first name
     * @param lastName   The customer's last name
     * @param postalCode The customer's postal code
     */
    public void fillInformation(String firstName, String lastName, String postalCode) {
        firstNameField.sendKeys(firstName);   // Enter first name into the First Name field
        lastNameField.sendKeys(lastName);     // Enter last name into the Last Name field
        postalCodeField.sendKeys(postalCode); // Enter postal code into the Postal Code field
        continueButton.click();               // Submit the form by clicking Continue
    }
}