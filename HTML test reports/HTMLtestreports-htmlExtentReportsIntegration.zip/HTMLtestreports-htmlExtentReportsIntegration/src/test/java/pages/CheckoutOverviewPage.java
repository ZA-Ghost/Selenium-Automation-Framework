package pages;

import base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * CheckoutOverviewPage represents the "Checkout: Overview" page.
 *
 * This is the order summary step where the user can review their
 * items and totals before placing the final order.
 */
public class CheckoutOverviewPage extends BasePage {

    // The page heading confirming we are on the order overview step
    @FindBy(xpath = "//span[contains(text(),'Checkout: Overview')]")
    private WebElement overviewTitle;

    // The Finish button that completes the order and triggers the confirmation page
    @FindBy(name = "finish")
    private WebElement finishButton;

    /**
     * @param driver The active WebDriver session
     */
    public CheckoutOverviewPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Returns whether the overview page title is displayed.
     * Used to confirm that the form submission navigated to this step.
     *
     * @return true if the title is visible, false otherwise
     */
    public boolean isTitleDisplayed() {
        return overviewTitle.isDisplayed();
    }

    /**
     * Clicks the Finish button to place the order and navigate to the confirmation page.
     */
    public void finishOrder() {
        finishButton.click();
    }
}