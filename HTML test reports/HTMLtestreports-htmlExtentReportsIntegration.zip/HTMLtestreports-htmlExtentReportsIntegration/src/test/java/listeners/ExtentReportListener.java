package listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import utils.ExtentReportManager;
import utils.ScreenshotUtil;

/**
 * ExtentReportListener is a TestNG ITestListener that hooks into the test lifecycle
 * and logs each result directly into the Extent HTML report.
 *
 * It is registered in the TestNG XML suite files — no changes to test classes are needed.
 *
 * Events handled:
 *   onTestStart       — creates a new test entry in the report
 *   onTestSuccess     — marks the entry as PASS (green)
 *   onTestFailure     — marks the entry as FAIL (red), logs the exception, attaches a screenshot
 *   onTestSkipped     — marks the entry as SKIP (orange)
 *   onFinish          — flushes all results to the HTML file
 */
public class ExtentReportListener implements ITestListener {

    private static final ExtentReports extent = ExtentReportManager.getInstance();

    /*
     * ThreadLocal ensures that parallel test execution on multiple browsers
     * does not mix up test entries between threads. Each thread gets
     * its own ExtentTest reference.
     */
    private static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    /**
     * Fires when a test method begins.
     * Creates a new named entry in the report and stores it in ThreadLocal.
     *
     * The browser name is read from the TestNG context parameter so each
     * report entry shows which browser it ran on.
     */
    @Override
    public void onTestStart(ITestResult result) {
        String browserName = result.getTestContext().getCurrentXmlTest().getParameter("browser");
        String browser = (browserName != null) ? browserName : "chrome";

        // Create a report entry named after the test method, tagged with the browser
        ExtentTest test = extent.createTest(
                result.getMethod().getMethodName(),
                "Browser: <b>" + browser.toUpperCase() + "</b>"
        );

        extentTest.set(test); // Store in ThreadLocal so onTestSuccess/Failure can access it
    }

    /**
     * Fires when a test method passes.
     * Logs a green PASS label in the report entry.
     */
    @Override
    public void onTestSuccess(ITestResult result) {
        extentTest.get().pass(
                MarkupHelper.createLabel("PASSED", ExtentColor.GREEN)
        );
    }

    /**
     * Fires when a test method fails.
     * Logs a red FAIL label, the full exception message, and attaches a screenshot.
     *
     * The screenshot is taken from the WebDriver instance stored in the test class.
     * If the driver is unavailable, failure is still logged without a screenshot.
     */
    @Override
    public void onTestFailure(ITestResult result) {
        extentTest.get().fail(
                MarkupHelper.createLabel("FAILED", ExtentColor.RED)
        );

        // Log the exception message so the cause is visible in the report
        extentTest.get().fail(result.getThrowable());

        // Attempt to capture and attach a screenshot of the failure state
        try {
            Object testInstance = result.getInstance();
            WebDriver driver = (WebDriver) testInstance.getClass()
                    .getField("driver")
                    .get(testInstance);

            if (driver != null) {
                String screenshotPath = ScreenshotUtil.capture(driver, result.getMethod().getMethodName());
                extentTest.get().addScreenCaptureFromPath(screenshotPath,
                        "Screenshot at point of failure");
            }

        } catch (Exception e) {
            extentTest.get().info("Screenshot could not be captured: " + e.getMessage());
        }
    }

    /**
     * Fires when a test method is skipped.
     * Logs an orange SKIP label in the report entry.
     */
    @Override
    public void onTestSkipped(ITestResult result) {
        extentTest.get().skip(
                MarkupHelper.createLabel("SKIPPED", ExtentColor.ORANGE)
        );
    }

    /**
     * Fires after all tests in the suite have completed.
     * Flushes all buffered test results to the HTML report file.
     * Without flush(), the report file will be empty or incomplete.
     */
    @Override
    public void onFinish(ITestContext context) {
        if (extent != null) {
            extent.flush();
        }
    }
}