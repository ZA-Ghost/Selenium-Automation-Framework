package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

/**
 * OnlineOrderTest validates the complete end-to-end purchase flow on SauceDemo.
 *
 * This class only contains test logic — no element locators, no driver setup,
 * and no browser configuration. All of that is handled by BaseTest (setup/teardown)
 * and the individual Page Object classes (element interaction).
 *
 * Each test method represents one step in the purchase journey and uses
 * a Page Object to interact with that step's UI.
 */
public class OnlineOrderTest extends BaseTest {

    /**
     * Test 1: Verifies that a user can log in with valid credentials.
     *
     * Uses LoginPage to submit the login form and InventoryPage to confirm
     * the Products page is displayed afterwards.
     */
    @Test(priority = 1)
    public void testLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("standard_user", "secret_sauce"); // Submit the login form with valid credentials

        InventoryPage inventoryPage = new InventoryPage(driver);
        Assert.assertEquals(inventoryPage.getPageTitle(), "Products",
                "Login failed — Products page title not found.");
    }

    /**
     * Test 2: Verifies that a product can be added to the shopping cart.
     *
     * Uses InventoryPage to add the backpack and checks the cart badge updates to "1".
     */
    @Test(priority = 2)
    public void testAddToCart() {
        InventoryPage inventoryPage = new InventoryPage(driver);
        inventoryPage.addBackpackToCart(); // Click the Add to Cart button for the Sauce Labs Backpack

        Assert.assertEquals(inventoryPage.getCartBadgeCount(), "1",
                "Cart badge did not update — item may not have been added.");
    }

    /**
     * Test 3: Verifies that clicking the cart icon opens the Cart page.
     *
     * Uses CartPage to open the cart and confirms the "Your Cart" title is visible.
     */
    @Test(priority = 3)
    public void testGoToCartPage() {
        CartPage cartPage = new CartPage(driver);
        cartPage.openCart(); // Click the cart icon in the navigation bar

        Assert.assertTrue(cartPage.isCartTitleDisplayed(),
                "Cart page did not load — 'Your Cart' title not found.");
    }

    /**
     * Test 4: Verifies that clicking Checkout opens the checkout information form.
     *
     * Uses CartPage to click Checkout and CheckoutInfoPage to confirm the form is displayed.
     */
    @Test(priority = 4)
    public void testCheckoutStart() {
        CartPage cartPage = new CartPage(driver);
        cartPage.proceedToCheckout(); // Click the Checkout button on the cart page

        CheckoutInfoPage checkoutInfoPage = new CheckoutInfoPage(driver);
        Assert.assertTrue(checkoutInfoPage.isTitleDisplayed(),
                "Checkout information page did not load.");
    }

    /**
     * Test 5: Verifies that customer information can be submitted on the checkout form.
     *
     * Uses CheckoutInfoPage to fill in the form and CheckoutOverviewPage to confirm
     * navigation to the order overview step.
     */
    @Test(priority = 5)
    public void testCheckoutInformation() {
        CheckoutInfoPage checkoutInfoPage = new CheckoutInfoPage(driver);
        checkoutInfoPage.fillInformation("Khwezi", "Test", "1234"); // Fill in and submit the checkout form

        CheckoutOverviewPage overviewPage = new CheckoutOverviewPage(driver);
        Assert.assertTrue(overviewPage.isTitleDisplayed(),
                "Checkout overview page did not load after submitting information.");
    }

    /**
     * Test 6: Verifies that the order can be successfully completed.
     *
     * Uses CheckoutOverviewPage to click Finish and ConfirmationPage to assert
     * the expected thank-you message is shown.
     */
    @Test(priority = 6)
    public void testFinishCheckout() {
        CheckoutOverviewPage overviewPage = new CheckoutOverviewPage(driver);
        overviewPage.finishOrder(); // Click the Finish button to place the order

        ConfirmationPage confirmationPage = new ConfirmationPage(driver);
        Assert.assertEquals(confirmationPage.getConfirmationText(), "Thank you for your order!",
                "Order confirmation message not displayed — checkout may have failed.");
    }
}