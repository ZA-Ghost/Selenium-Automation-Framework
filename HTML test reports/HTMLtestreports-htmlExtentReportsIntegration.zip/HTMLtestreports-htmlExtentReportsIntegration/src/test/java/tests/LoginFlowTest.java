package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.InventoryPage;
import pages.LoginPage;

/**
 * LoginFlowTest isolates and validates the login flow only.
 *
 * Covers three distinct login scenarios:
 *   1. Successful login with valid credentials
 *   2. Failed login with an incorrect password
 *   3. Failed login with a locked-out user account
 *
 * Each test navigates back to the login page before running so the
 * suite can execute cleanly in any order.
 *
 * Thread.sleep() pauses are added so each result is clearly
 * visible during execution.
 */
public class LoginFlowTest extends BaseTest {

    /**
     * Test 1: Verifies that a standard user can log in successfully.
     * Confirms the Products page title is displayed after login.
     */
    @Test(priority = 1)
    public void testValidLogin() throws InterruptedException {
        driver.get("https://www.saucedemo.com/");
        Thread.sleep(1500); // Let the login page fully render before interacting

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("standard_user", "secret_sauce");

        Thread.sleep(2000); // Pause so the Products page is clearly visible after login

        InventoryPage inventoryPage = new InventoryPage(driver);
        Assert.assertEquals(inventoryPage.getPageTitle(), "Products",
                "Valid login failed — Products page not displayed.");
    }

    /**
     * Test 2: Verifies that login fails with an incorrect password.
     * Confirms an error message is displayed and the user remains on the login page.
     */
    @Test(priority = 2)
    public void testInvalidPassword() throws InterruptedException {
        driver.get("https://www.saucedemo.com/");
        Thread.sleep(1500); // Let the login page reload before interacting

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("standard_user", "wrong_password");

        Thread.sleep(2000); // Pause so the error message is clearly visible

        String errorMessage = loginPage.getErrorMessage();
        Assert.assertTrue(errorMessage.contains("Username and password do not match"),
                "Expected error message not shown for invalid password.");
    }

    /**
     * Test 3: Verifies that a locked-out user cannot log in.
     * Confirms the appropriate locked-out error message is displayed.
     */
    @Test(priority = 3)
    public void testLockedOutUser() throws InterruptedException {
        driver.get("https://www.saucedemo.com/");
        Thread.sleep(1500); // Let the login page reload before interacting

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("locked_out_user", "secret_sauce");

        Thread.sleep(2000); // Pause so the locked-out error message is clearly visible

        String errorMessage = loginPage.getErrorMessage();
        Assert.assertTrue(errorMessage.contains("Sorry, this user has been locked out"),
                "Expected locked-out error message not displayed.");
    }
}