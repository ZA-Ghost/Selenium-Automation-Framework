package utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ScreenshotUtil captures a PNG screenshot of the current browser state
 * and saves it to the screenshots/ directory.
 *
 * Called automatically by ExtentReportListener on test failure so every
 * failed test has a visual record of what the browser looked like at the
 * point the assertion failed.
 *
 * Filenames include the test name and a timestamp to prevent overwrites
 * across multiple runs or browsers:
 *   e.g. screenshots/testLogin_Chrome_2024-01-15_14-32-07.png
 */
public class ScreenshotUtil {

    /**
     * Captures a screenshot and saves it to the screenshots/ directory.
     *
     * @param driver   The active WebDriver session to capture from
     * @param testName The name of the failing test — used in the filename
     * @return The file path of the saved screenshot, for embedding in the report
     */
    public static String capture(WebDriver driver, String testName) {

        // Cast the driver to TakesScreenshot — all major WebDriver implementations support this
        TakesScreenshot ts = (TakesScreenshot) driver;
        File source = ts.getScreenshotAs(OutputType.FILE);

        // Build a timestamped filename to avoid overwriting previous screenshots
        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String filePath = "screenshots/" + testName + "_" + timestamp + ".png";

        try {
            FileUtils.copyFile(source, new File(filePath)); // Save the screenshot to disk
        } catch (IOException e) {
            System.err.println("Failed to save screenshot: " + e.getMessage());
        }

        return filePath; // Return the path so the listener can embed it in the report
    }
}