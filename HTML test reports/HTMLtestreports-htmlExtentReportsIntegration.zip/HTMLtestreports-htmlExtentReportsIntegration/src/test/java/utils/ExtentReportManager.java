package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

/**
 * ExtentReportManager is a singleton utility that creates and configures
 * the single shared ExtentReports instance used across the entire test run.
 *
 * Using a singleton ensures that all test classes write their results into
 * one combined report file rather than overwriting each other.
 *
 * The final HTML report is written to: reports/ExtentReport.html
 */
public class ExtentReportManager {

    // The single shared ExtentReports instance for the entire test run
    private static ExtentReports extent;

    /**
     * Returns the shared ExtentReports instance, creating it on first call.
     *
     * ExtentSparkReporter controls the output file path, theme, and document title.
     * ExtentReports wraps the reporter and is used by tests to log results.
     *
     * @return The configured ExtentReports instance
     */
    public static ExtentReports getInstance() {

        if (extent == null) {

            // SparkReporter defines where the HTML file is saved and how it looks
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter("reports/ExtentReport.html");

            sparkReporter.config().setDocumentTitle("SauceDemo Automation Report"); // Browser tab title
            sparkReporter.config().setReportName("Cross-Browser Test Results");     // Heading inside the report
            sparkReporter.config().setTheme(Theme.DARK);                            // DARK or STANDARD theme
            sparkReporter.config().setTimeStampFormat("dd MMM yyyy HH:mm:ss");      // Timestamp format on each test entry

            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);

            // System-level info shown in the Environment section of the report
            extent.setSystemInfo("Project",     "SauceDemo Automation Suite");
            extent.setSystemInfo("Environment", "QA");
            extent.setSystemInfo("Tester",      "Khwezi");
            extent.setSystemInfo("Base URL",    "https://www.saucedemo.com");

        }

        return extent;
    }
}