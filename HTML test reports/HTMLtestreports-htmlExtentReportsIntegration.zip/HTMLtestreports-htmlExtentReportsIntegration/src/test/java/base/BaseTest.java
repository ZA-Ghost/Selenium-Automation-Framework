package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.time.Duration;
import java.util.Map;

/**
 * BaseTest is the parent class for all test classes.
 *
 * It handles browser setup and teardown for Chrome, Firefox, and Edge.
 * The browser is controlled by the "browser" parameter passed in from
 * the TestNG XML suite file — no code changes are needed to switch browsers.
 *
 * If no browser parameter is supplied, Chrome is used as the default.
 */
public class BaseTest {

    protected WebDriver driver;

    /**
     * Runs once before any tests in the class execute.
     *
     * Reads the "browser" parameter from the TestNG XML suite,
     * initialises the correct WebDriver, and navigates to SauceDemo.
     *
     * @param browser The browser name passed from testng.xml ("chrome", "firefox", "edge")
     */
    @BeforeClass
    @Parameters("browser")
    public void setUp(@Optional("chrome") String browser) throws InterruptedException {

        // Initialise the correct driver based on the browser parameter
        switch (browser.toLowerCase()) {

            case "firefox":
                WebDriverManager.firefoxdriver().setup(); // Auto-download the correct GeckoDriver
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.addArguments("--disable-notifications");
                driver = new FirefoxDriver(firefoxOptions);
                break;

            case "edge":
                System.setProperty("webdriver.edge.driver", "drivers/msedgedriver.exe");
                EdgeOptions edgeOptions = new EdgeOptions();
                edgeOptions.addArguments("--disable-notifications");
                edgeOptions.addArguments("--disable-save-password-bubble");
                edgeOptions.addArguments("--disable-features=PasswordLeakDetection,SafeBrowsingEnhancedProtection");
                edgeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
                edgeOptions.setExperimentalOption("prefs", Map.of(
                        "credentials_enable_service",                           false,
                        "profile.password_manager_enabled",                     false,
                        "profile.password_manager_leak_detection",              false,
                        "profile.default_content_setting_values.notifications", 2
                ));
                driver = new EdgeDriver(edgeOptions);
                break;
            case "chrome":
            default:
                WebDriverManager.chromedriver().setup(); // Auto-download the correct ChromeDriver
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--disable-notifications");
                chromeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
                driver = new ChromeDriver(chromeOptions);
                break;
        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // Wait up to 10s for elements before throwing an exception
        driver.get("https://www.saucedemo.com/");

        Thread.sleep(1500); // Let the landing page fully render before any test begins

        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();

        // ── Suppress automation banners and notifications ──────────────────────
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-save-password-bubble");
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});

        // ── Suppress "Change your password" / breach detection dialog ─────────
        options.addArguments("--disable-features=PasswordLeakDetection,SafeBrowsingEnhancedProtection,TrustSafetySentimentSurvey");

        // ── Disable Chrome password manager via prefs ──────────────────────────
        options.setExperimentalOption("prefs", Map.of(
                "credentials_enable_service",                              false,
                "profile.password_manager_enabled",                        false,
                "profile.password_manager_leak_detection",                 false,
                "profile.default_content_setting_values.notifications",    2
        ));

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com/");
    }

    /**
     * Runs once after all tests in the class have completed.
     * Closes the browser and ends the WebDriver session.
     */
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}