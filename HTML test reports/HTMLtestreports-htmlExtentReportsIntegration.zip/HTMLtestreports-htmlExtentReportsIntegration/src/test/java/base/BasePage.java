package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * BasePage is the parent class for all Page Object classes.
 *
 * Every page class extends this so they all share:
 *   - A reference to the same WebDriver instance
 *   - PageFactory initialisation, which wires up @FindBy annotations
 *
 * This eliminates the need to repeat driver setup and PageFactory.initElements()
 * in every page class individually.
 */
public class BasePage {

    protected WebDriver driver;

    /**
     * Constructor accepts the shared WebDriver instance from the test,
     * stores it for use in page methods, and initialises PageFactory
     * annotations on the subclass.
     *
     * @param driver The active WebDriver session
     */
    public BasePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
}