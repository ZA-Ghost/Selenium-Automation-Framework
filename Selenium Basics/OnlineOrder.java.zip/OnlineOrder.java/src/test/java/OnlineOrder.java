import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.*;
import java.time.Duration;
import java.util.Map;

public class OnlineOrder {

    // Declare a WebDriver instance to be shared across all test methods in this class
    WebDriver driver;

    /**
     * Setup method that runs once before any test in this class is executed.
     * Initialises the ChromeDriver with custom options, maximises the browser window,
     * sets an implicit wait timeout, and navigates to the SauceDemo login page.
     */
    @BeforeClass
    public void setup() {

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");                              // Prevent browser pop-ups from interrupting tests
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"}); // Hide the "Chrome is being controlled by automated software" banner

        driver = new ChromeDriver(options);                          // Launch Chrome with the configured options
        driver.manage().window().maximize();                         // Maximise the browser window for consistent element visibility
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // Wait up to 10 seconds for elements to appear before throwing an exception
        driver.get("https://www.saucedemo.com/");                    // Open the SauceDemo website



        // ── Suppress automation banners and notifications ──────────────────────
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-save-password-bubble");
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});

        // ── Suppress "Change your password" / breach detection dialog ─────────
        options.addArguments("--disable-features=PasswordLeakDetection,SafeBrowsingEnhancedProtection,TrustSafetySentimentSurvey");

        // ── Disable Chrome password manager via prefs ──────────────────────────
        options.setExperimentalOption("prefs", Map.of(
                "credentials_enable_service",                              false,
                "profile.password_manager_enabled",                        false,
                "profile.password_manager_leak_detection",                 false,
                "profile.default_content_setting_values.notifications",    2
        ));

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com/");
    }

    /**
     * Test 1: Verifies that a user can log in with valid credentials.
     * Enters the username and password, clicks the login button,
     * and asserts that the Products page title is displayed after login.
     */
    @Test(priority = 1)
    public void testLogin() {
        driver.findElement(By.id("user-name")).sendKeys("standard_user"); // Type the username into the username field
        driver.findElement(By.id("password")).sendKeys("secret_sauce");   // Type the password into the password field
        driver.findElement(By.id("login-button")).click();                // Click the login button to submit credentials

        // Locate the page title element and verify it reads "Products" to confirm successful login
        WebElement title = driver.findElement(By.className("title"));
        Assert.assertEquals(title.getText(), "Products", "Login failed or wrong page.");
    }

    /**
     * Test 2: Verifies that a product can be added to the shopping cart.
     * Clicks the "Add to Cart" button for the Sauce Labs Backpack,
     * then asserts that the cart badge updates to reflect 1 item.
     */
    @Test(priority = 2)
    public void testAddToCart() {
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click(); // Click the Add to Cart button for the Sauce Labs Backpack

        // Locate the cart badge (item count indicator) and verify it shows "1"
        WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
        Assert.assertEquals(cartBadge.getText(), "1", "Item was not added to cart.");
    }

    /**
     * Test 3: Verifies that clicking the cart icon navigates to the Cart page.
     * Locates the shopping cart container link and clicks it,
     * then asserts that the "Your Cart" heading is visible on the resulting page.
     */
    @Test(priority = 3)
    public void testGoToCartPage() {
        driver.findElement(By.xpath("//div[@id='shopping_cart_container']/a")).click(); // Click the cart icon in the top-right corner to open the cart

        // Confirm the cart page has loaded by checking for the "Your Cart" title
        WebElement cartTitle = driver.findElement(By.xpath("//span[contains(text(),'Your Cart')]"));
        Assert.assertTrue(cartTitle.isDisplayed(), "Cart page not loaded.");
    }

    /**
     * Test 4: Verifies that clicking the Checkout button opens the checkout information form.
     * Clicks the checkout button on the cart page and asserts that
     * the "Checkout: Your Information" page title is displayed.
     */
    @Test(priority = 4)
    public void testCheckoutStart() {
        driver.findElement(By.id("checkout")).click(); // Click the Checkout button to proceed from the cart to the checkout form

        // Verify the checkout information page has loaded by checking for its title
        WebElement checkoutTitle = driver.findElement(By.xpath("//span[contains(text(),'Checkout: Your Information')]"));
        Assert.assertTrue(checkoutTitle.isDisplayed(), "Checkout page not opened.");
    }

    /**
     * Test 5: Verifies that customer information can be entered and submitted on the checkout form.
     * Fills in the first name, last name, and postal code fields, then clicks Continue.
     * Asserts that the "Checkout: Overview" page is displayed after form submission.
     */
    @Test(priority = 5)
    public void testCheckoutInformation() {
        driver.findElement(By.id("first-name")).sendKeys("Khwezi"); // Enter the first name into the First Name field
        driver.findElement(By.id("last-name")).sendKeys("Test");    // Enter the last name into the Last Name field
        driver.findElement(By.id("postal-code")).sendKeys("1234");  // Enter the postal code into the Postal Code field
        driver.findElement(By.id("continue")).click();              // Click the Continue button to proceed to the order overview

        // Confirm navigation to the overview page by verifying its title is displayed
        WebElement overviewTitle = driver.findElement(By.xpath("//span[contains(text(),'Checkout: Overview')]"));
        Assert.assertTrue(overviewTitle.isDisplayed(), "Overview page not loaded.");
    }

    /**
     * Test 6: Verifies that the order can be finalised successfully.
     * Clicks the Finish button on the order overview page and asserts that
     * the order confirmation message "Thank you for your order!" is displayed.
     */
    @Test(priority = 6)
    public void testFinishCheckout() {
        driver.findElement(By.name("finish")).click(); // Click the Finish button to place the order

        // Locate the confirmation header and verify it contains the expected thank-you message
        WebElement thankYou = driver.findElement(By.className("complete-header"));
        Assert.assertEquals(thankYou.getText(), "Thank you for your order!", "Checkout not completed successfully.");
    }

    /**
     * Teardown method that runs once after all tests in this class have completed.
     * Closes the browser and ends the WebDriver session to free up system resources.
     */
    @AfterClass
    public void tearDown() {
        driver.quit(); // Close all browser windows and terminate the ChromeDriver session
    }
}